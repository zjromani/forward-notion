"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const email_reception_1 = require("./src/services/imap/email-reception");
const send_to_notion_1 = require("./src/services/notion/send-to-notion");
const transform_data_1 = require("./src/services/notion/transform-data");
(0, email_reception_1.fetchUnseenEmails)()
    .then(emails => {
    return Promise.all(emails.map(email => (0, transform_data_1.processEmailContent)(email)));
})
    .then(parsedEmails => {
    const email = parsedEmails[0];
    // return Promise.all(
    //   parsedEmails.map(parsedEmail => sendToNotion(parsedEmail))
    // );
    // console.log(email);
    return (0, send_to_notion_1.sendToNotion)(email);
})
    .then(results => {
    console.log("All emails have been sent to Notion:", results);
})
    .catch(error => {
    console.error("An error occurred:", error);
});
//# sourceMappingURL=test.js.map