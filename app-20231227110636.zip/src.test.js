"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const email_reception_1 = require("./src/services/imap/email-reception");
(0, email_reception_1.fetchUnseenEmails)();
//# sourceMappingURL=src.test.js.map