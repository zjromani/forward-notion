"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendToNotion = void 0;
const validated_config_1 = require("../../config/validated-config");
const client_1 = __importDefault(require("./client"));
async function sendToNotion(email) {
    const response = await client_1.default.pages.create({
        parent: { database_id: validated_config_1.config.notionDatabaseId },
        properties: {
            Name: {
                title: [
                    {
                        text: {
                            content: email.subject ?? "Default Subject"
                        }
                    }
                ]
            }
        },
        children: [
            {
                object: "block",
                type: "paragraph",
                paragraph: {
                    rich_text: [
                        {
                            type: "text",
                            text: {
                                content: email.body
                            }
                        }
                    ]
                }
            }
        ]
    });
    return response;
}
exports.sendToNotion = sendToNotion;
//# sourceMappingURL=send-to-notion.js.map