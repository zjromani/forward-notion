"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@notionhq/client");
const validated_config_1 = require("../../config/validated-config");
const notion = new client_1.Client({ auth: validated_config_1.config.notionApiKey });
exports.default = notion;
//# sourceMappingURL=client.js.map