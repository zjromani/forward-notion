export declare function sendToNotion(email: any): Promise<import("@notionhq/client/build/src/api-endpoints").CreatePageResponse>;
//# sourceMappingURL=send-to-notion.d.ts.map