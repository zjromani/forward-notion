import { Client } from "@notionhq/client";
declare const notion: Client;
export default notion;
//# sourceMappingURL=client.d.ts.map