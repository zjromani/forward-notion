"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchUnseenEmails = void 0;
const imap_1 = __importDefault(require("imap"));
const mailparser_1 = require("mailparser");
const zod_1 = require("zod");
const validated_config_1 = require("../../config/validated-config");
const imapConfigSchema = zod_1.z.object({
    user: zod_1.z.string(),
    password: zod_1.z.string(),
    host: zod_1.z.string(),
    port: zod_1.z.number(),
    tls: zod_1.z.boolean(),
    tlsOptions: zod_1.z.object({
        rejectUnauthorized: zod_1.z.boolean()
    })
});
const imapConfig = {
    user: validated_config_1.config.gmailUser,
    password: validated_config_1.config.gmailPassword,
    host: "imap.gmail.com",
    port: 993,
    tls: true,
    tlsOptions: { rejectUnauthorized: false }
};
const validatedImapConfig = imapConfigSchema.parse(imapConfig);
const imap = new imap_1.default(validatedImapConfig);
function openInbox(cb) {
    imap.openBox("INBOX", false, cb);
}
function fetchUnseenEmails() {
    return new Promise((resolve, reject) => {
        imap.once("ready", () => {
            openInbox((err) => {
                if (err) {
                    reject(err);
                    return;
                }
                // const searchCriteria = ["ALL"];
                const searchCriteria = [
                    "UNSEEN",
                    ["SINCE", new Date().toDateString().split(" ").slice(1).join("-")]
                ];
                const fetchOptions = {
                    bodies: ["HEADER", "TEXT"],
                    markSeen: false
                };
                imap.search(searchCriteria, (searchErr, results) => {
                    if (searchErr) {
                        reject(searchErr);
                        return;
                    }
                    const fetchedEmails = [];
                    const fetch = imap.fetch(results, fetchOptions);
                    fetch.on("message", (msg) => {
                        msg.on("body", (stream) => {
                            (0, mailparser_1.simpleParser)(stream, (parseErr, mail) => {
                                if (parseErr) {
                                    reject(parseErr);
                                    return;
                                }
                                fetchedEmails.push(mail);
                            });
                        });
                    });
                    fetch.on("end", () => {
                        imap.end();
                        resolve(fetchedEmails);
                    });
                });
            });
        });
        imap.once("error", (err) => {
            console.error(err);
            reject(err);
        });
        imap.connect();
    });
}
exports.fetchUnseenEmails = fetchUnseenEmails;
//# sourceMappingURL=email-reception.js.map