"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const email_reception_1 = require("./services/imap/email-reception");
const send_to_notion_1 = require("./services/notion/send-to-notion");
const transform_data_1 = require("./services/notion/transform-data");
const handler = async () => {
    try {
        console.log("Handler started");
        const emails = await (0, email_reception_1.fetchUnseenEmails)();
        console.log(`Fetched emails: ${emails.length}`);
        const parsedEmails = await Promise.all(emails.map(email => (0, transform_data_1.processEmailContent)(email)));
        console.log(`Parsed emails: ${parsedEmails.length}`);
        const results = await (0, send_to_notion_1.sendToNotion)(parsedEmails[0]);
        console.log("Email sent to Notion:", results);
        return results;
    }
    catch (error) {
        console.error("An error occurred:", error);
        throw error;
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map